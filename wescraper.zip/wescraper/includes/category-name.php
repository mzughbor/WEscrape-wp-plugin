<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'log.php';

class CategoryManager {
    private $taxonomy = 'course_category';

    public function get_category_id($category_name) {
        global $wpdb;
        
        if (empty($category_name)) {
            wescraper_log("Error: Category name is empty.");
            return false;
        }
        
        wescraper_log("Checking category: " . $category_name . " in taxonomy: " . $this->taxonomy);

        // Ensure taxonomy exists before proceeding
        if (!taxonomy_exists($this->taxonomy)) {
            wescraper_log("Warning: Taxonomy '" . $this->taxonomy . "' not found. Attempting to register it.");
            add_action('init', function() {
                register_taxonomy('course_category', 'courses', [
                    'label' => __('Course Categories'),
                    'rewrite' => ['slug' => 'course-category'],
                    'hierarchical' => true,
                ]);
            });

            // Wait for taxonomy to be registered
            flush_rewrite_rules();

            if (!taxonomy_exists($this->taxonomy)) {
                wescraper_log("Error: Taxonomy still does not exist after attempt to register.");
                return false;
            }
        }

        // Check if the category exists
        $term_id = $wpdb->get_var($wpdb->prepare(
            "SELECT t.term_id FROM {$wpdb->terms} t 
             JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id 
             WHERE t.name = %s AND tt.taxonomy = %s",
            $category_name,
            $this->taxonomy
        ));

        if ($term_id) {
            wescraper_log("Category '" . $category_name . "' exists with ID: " . $term_id);
            return intval($term_id);
        } else {
            wescraper_log("Category '" . $category_name . "' does not exist. Attempting to create.");

            // Create category if not found
            $term = wp_insert_term(
                $category_name,
                $this->taxonomy
            );

            if (!is_wp_error($term) && isset($term['term_id'])) {
                wescraper_log("Category '" . $category_name . "' created successfully. Term ID: " . intval($term['term_id']));
                return intval($term['term_id']);
            } else {
                $error_message = is_wp_error($term) ? $term->get_error_message() : 'Unknown error';
                wescraper_log("Failed to create category: " . $category_name . " - Error: " . $error_message);
                return false;
            }
        }
    }
}
